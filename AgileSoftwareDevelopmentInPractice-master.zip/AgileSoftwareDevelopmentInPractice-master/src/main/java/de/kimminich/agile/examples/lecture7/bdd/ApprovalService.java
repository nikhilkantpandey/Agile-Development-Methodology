package de.kimminich.agile.examples.lecture7.bdd;


public class ApprovalService {

    public boolean hasExistingApproval(Order order, String manager) {
        // ...
        return true;
    }

}
