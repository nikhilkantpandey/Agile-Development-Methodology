package de.kimminich.agile.examples.lecture3.lawofdemeter;

public class D {

    public void d() {
    }

}
