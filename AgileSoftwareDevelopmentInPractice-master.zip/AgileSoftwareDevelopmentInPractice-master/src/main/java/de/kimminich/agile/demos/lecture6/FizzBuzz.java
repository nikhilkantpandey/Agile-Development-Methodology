package de.kimminich.agile.demos.lecture6;

public class FizzBuzz {
}
