package de.kimminich.agile.solutions.lecture3.methodobject;

import java.util.Set;

public class SetBenchmark {

    public SetBenchmark(Set<String> set, int valueLength, int numberOfOperations) {
        // ...
    }

    public void execute() {
        // ...
    }

}
