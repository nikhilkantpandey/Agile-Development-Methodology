package de.kimminich.agile.solutions.lecture3.methodobject;

import java.util.List;

public class ListBenchmark {

    public ListBenchmark(List<String> list, int valueLength, int numberOfOperations) {
        // ...
    }

    public void execute() {
        // ...
    }

}
