package de.kimminich.agile.examples.lecture3.lawofdemeter;

public class B {

    private X x;

    public void b() {
    }

    public X getX() {
        return x;
    }

}
