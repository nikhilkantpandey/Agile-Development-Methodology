package de.kimminich.agile.examples.lecture3.lawofdemeter;

public class Y {

    public void y() {
    }

}
