package de.kimminich.agile.exercises.lecture2.tcg;

public class Player {

    private int life = 30;
    private int mana = 0;
    // TODO Implement card deck and hand

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }
}
