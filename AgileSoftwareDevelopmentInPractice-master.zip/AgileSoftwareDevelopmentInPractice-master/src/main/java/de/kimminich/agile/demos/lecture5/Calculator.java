package de.kimminich.agile.demos.lecture5;

public interface Calculator {
    int sum(int a, int b);

    int min(int a, int b);

    int max(int a, int b);

    int modulo(int a, int b);

    double div(double a, double b);
}
