# Disclaimer

The libraries in this folder are part of the [OWASP Zed Attack Proxy (ZAP)](https://www.owasp.org/index.php/OWASP_Zed_Attack_Proxy_Project) project dependencies. They are needed only to compile the source files in ```/src/de/kimminich/agile/examples/lecture4```.
None of these libraries is relevant for the remainder of exercises and examples.

ZAP is an HTTP/HTTPS proxy for assessing web application security. It is distributed under the [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0).